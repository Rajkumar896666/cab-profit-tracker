#!/usr/bin/env bash
set -e
echo "Cab Profit Tracker - Step 1"
echo "Java:"
java -version
echo "Gradle:"
gradle --version
echo "Building debug APK..."
gradle assembleDebug
echo "Done. APK: app/build/outputs/apk/debug/app-debug.apk"
