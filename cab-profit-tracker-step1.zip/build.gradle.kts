plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.3.12" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.12" apply false
    id("com.google.devtools.ksp") version "2.3.12" apply false
}
