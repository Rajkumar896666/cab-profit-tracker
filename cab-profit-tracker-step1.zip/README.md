# Cab Profit Tracker

Android app for cab drivers to track income, expenses, kilometres and profit.

## Step 1 MVP

- Daily income
- KM driven
- CNG/Petrol expense
- Food expense
- Maintenance expense
- EMI allocation
- Other expenses
- Net profit
- Earnings per km
- Cost per km
- Offline Room database
- Jetpack Compose UI

## Tech stack

- Kotlin
- Jetpack Compose
- Material 3
- Room
- Kotlin Coroutines
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Minimum Android API 26

## Open in Codespace

Open this repository in your GitHub Codespace, then run:

```bash
gradle assembleDebug
```

If Android SDK/Gradle tooling is already configured, the generated APK will be under:

`app/build/outputs/apk/debug/app-debug.apk`

For Android Studio, open the repository root and sync Gradle.

## Package

`com.rajkumar.cabprofit`

## Next steps

1. Improve dashboard cards and navigation.
2. Add monthly filtering and charts.
3. Add edit-entry support.
4. Add export/backup.
5. Add multiple vehicles.
6. Add privacy policy and Play Store assets.
7. Add ads/Pro only after the core app is stable.
