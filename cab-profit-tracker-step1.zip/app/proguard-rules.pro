# Cab Profit Tracker - app-specific R8 rules.
# Keep empty for the MVP; add rules here when third-party SDKs are introduced.
