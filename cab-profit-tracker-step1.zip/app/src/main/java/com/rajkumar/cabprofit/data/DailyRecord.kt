package com.rajkumar.cabprofit.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_records")
data class DailyRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateMillis: Long,
    val income: Double,
    val km: Double,
    val fuelExpense: Double,
    val foodExpense: Double,
    val maintenanceExpense: Double,
    val emiExpense: Double,
    val otherExpense: Double,
    val notes: String = ""
) {
    val totalExpenses: Double
        get() = fuelExpense + foodExpense + maintenanceExpense + emiExpense + otherExpense

    val netProfit: Double
        get() = income - totalExpenses

    val earningsPerKm: Double
        get() = if (km > 0) income / km else 0.0

    val costPerKm: Double
        get() = if (km > 0) totalExpenses / km else 0.0
}
