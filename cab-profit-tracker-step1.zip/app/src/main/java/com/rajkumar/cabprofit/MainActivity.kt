package com.rajkumar.cabprofit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.rajkumar.cabprofit.ui.CabProfitApp
import com.rajkumar.cabprofit.ui.theme.CabProfitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CabProfitTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    CabProfitApp()
                }
            }
        }
    }
}
