package com.rajkumar.cabprofit.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyRecordDao {
    @Query("SELECT * FROM daily_records ORDER BY dateMillis DESC, id DESC")
    fun observeAll(): Flow<List<DailyRecord>>

    @Insert
    suspend fun insert(record: DailyRecord)

    @Delete
    suspend fun delete(record: DailyRecord)
}
