package com.rajkumar.cabprofit.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rajkumar.cabprofit.data.AppDatabase
import com.rajkumar.cabprofit.data.DailyRecord
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardTotals(
    val income: Double = 0.0,
    val expenses: Double = 0.0,
    val profit: Double = 0.0,
    val km: Double = 0.0
) {
    val earningsPerKm: Double get() = if (km > 0) income / km else 0.0
    val costPerKm: Double get() = if (km > 0) expenses / km else 0.0
}

class CabProfitViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).dailyRecordDao()

    val records: StateFlow<List<DailyRecord>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val totals: StateFlow<DashboardTotals> = records
        .map { list ->
            DashboardTotals(
                income = list.sumOf { it.income },
                expenses = list.sumOf { it.totalExpenses },
                profit = list.sumOf { it.netProfit },
                km = list.sumOf { it.km }
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardTotals())

    fun addRecord(record: DailyRecord) {
        viewModelScope.launch { dao.insert(record) }
    }

    fun deleteRecord(record: DailyRecord) {
        viewModelScope.launch { dao.delete(record) }
    }
}
