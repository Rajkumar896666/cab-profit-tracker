package com.rajkumar.cabprofit.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rajkumar.cabprofit.data.DailyRecord
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CabProfitApp(vm: CabProfitViewModel = viewModel()) {
    var showAdd by remember { mutableStateOf(false) }
    val records by vm.records.collectAsState()
    val totals by vm.totals.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Cab Profit Tracker") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
        }
    ) { padding ->
        if (showAdd) {
            AddRecordScreen(
                onSave = {
                    vm.addRecord(it)
                    showAdd = false
                },
                onCancel = { showAdd = false },
                modifier = Modifier.padding(padding)
            )
        } else {
            DashboardScreen(
                totals = totals,
                records = records,
                onDelete = vm::deleteRecord,
                modifier = Modifier.padding(padding)
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    totals: DashboardTotals,
    records: List<DailyRecord>,
    onDelete: (DailyRecord) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Overall Summary",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            SummaryCard("Income", totals.income)
            SummaryCard("Expenses", totals.expenses)
            SummaryCard("Net Profit", totals.profit)
            SummaryCard("Earnings / km", totals.earningsPerKm)
            SummaryCard("Cost / km", totals.costPerKm)
        }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Daily Records", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (records.isEmpty()) {
            item {
                Text(
                    "No records yet. Tap + to add your first working day.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            items(records, key = { it.id }) { record ->
                RecordCard(record, onDelete)
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: Double) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label)
            Text(formatRupees(value), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RecordCard(record: DailyRecord, onDelete: (DailyRecord) -> Unit) {
    val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(record.dateMillis))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(date, fontWeight = FontWeight.Bold)
            Text("Income: ${formatRupees(record.income)}  •  KM: ${formatNumber(record.km)}")
            Text("Expenses: ${formatRupees(record.totalExpenses)}")
            Text("Profit: ${formatRupees(record.netProfit)}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { onDelete(record) }) {
                Text("Delete")
            }
        }
    }
}

@Composable
private fun AddRecordScreen(
    onSave: (DailyRecord) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var income by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var fuel by remember { mutableStateOf("") }
    var food by remember { mutableStateOf("") }
    var maintenance by remember { mutableStateOf("") }
    var emi by remember { mutableStateOf("") }
    var other by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Add Daily Entry", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item { MoneyField("Income (₹)", income) { income = it } }
        item { NumberField("KM driven", km) { km = it } }
        item { MoneyField("CNG / Petrol (₹)", fuel) { fuel = it } }
        item { MoneyField("Food (₹)", food) { food = it } }
        item { MoneyField("Maintenance (₹)", maintenance) { maintenance = it } }
        item { MoneyField("EMI allocation (₹)", emi) { emi = it } }
        item { MoneyField("Other expenses (₹)", other) { other = it } }
        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Notes") },
                minLines = 2
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        onSave(
                            DailyRecord(
                                dateMillis = System.currentTimeMillis(),
                                income = income.toDoubleOrNull() ?: 0.0,
                                km = km.toDoubleOrNull() ?: 0.0,
                                fuelExpense = fuel.toDoubleOrNull() ?: 0.0,
                                foodExpense = food.toDoubleOrNull() ?: 0.0,
                                maintenanceExpense = maintenance.toDoubleOrNull() ?: 0.0,
                                emiExpense = emi.toDoubleOrNull() ?: 0.0,
                                otherExpense = other.toDoubleOrNull() ?: 0.0,
                                notes = notes
                            )
                        )
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save")
                }
            }
        }
    }
}

@Composable
private fun MoneyField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.isEmpty() || it.matches(Regex("^\\d*(\\.\\d{0,2})?$"))) onValueChange(it) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true
    )
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.isEmpty() || it.matches(Regex("^\\d*(\\.\\d{0,2})?$"))) onValueChange(it) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true
    )
}

private fun formatRupees(value: Double): String =
    NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(value)

private fun formatNumber(value: Double): String =
    String.format(Locale.getDefault(), "%.1f", value)
