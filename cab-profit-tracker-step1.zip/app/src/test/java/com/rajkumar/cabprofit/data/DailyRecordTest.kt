package com.rajkumar.cabprofit.data

import org.junit.Assert.assertEquals
import org.junit.Test

class DailyRecordTest {
    @Test
    fun calculatesExpensesAndProfit() {
        val record = DailyRecord(
            dateMillis = 0L,
            income = 2800.0,
            km = 200.0,
            fuelExpense = 700.0,
            foodExpense = 200.0,
            maintenanceExpense = 150.0,
            emiExpense = 500.0,
            otherExpense = 50.0
        )

        assertEquals(1600.0, record.totalExpenses, 0.001)
        assertEquals(1200.0, record.netProfit, 0.001)
        assertEquals(14.0, record.earningsPerKm, 0.001)
        assertEquals(8.0, record.costPerKm, 0.001)
    }
}
